#!/bin/bash
for file in *
do
    echo ${file}
done
